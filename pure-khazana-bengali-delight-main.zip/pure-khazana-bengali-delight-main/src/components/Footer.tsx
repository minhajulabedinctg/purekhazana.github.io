import { Leaf, Facebook, Instagram, Youtube } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { href: "#home", label: "হোম" },
    { href: "#products", label: "পণ্যসমূহ" },
    { href: "#about", label: "আমাদের সম্পর্কে" },
    { href: "#contact", label: "যোগাযোগ" },
  ];

  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Youtube, href: "#", label: "YouTube" },
  ];

  return (
    <footer className="bg-foreground text-background py-12 md:py-16">
      <div className="container-custom">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <a href="#home" className="inline-flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <Leaf className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight">
                  Pure Khazana
                </span>
                <span className="text-xs text-background/60 leading-tight">
                  পিওর খাজানা
                </span>
              </div>
            </a>
            <p className="text-background/70 max-w-sm leading-relaxed">
              বিশুদ্ধতার প্রতীক পিওর খাজানা। খাঁটি মধু, ঘি, তেল এবং আরও অনেক
              প্রাকৃতিক পণ্য সরাসরি আপনার ঘরে।
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-4">দ্রুত লিংক</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-background/70 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-semibold text-lg mb-4">সোশ্যাল মিডিয়া</h4>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-primary transition-colors group"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5 text-background/70 group-hover:text-primary-foreground transition-colors" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-background/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-background/60 text-sm text-center md:text-left">
              © {currentYear} Pure Khazana | পিওর খাজানা। সর্বস্বত্ব সংরক্ষিত।
            </p>
            <p className="text-background/40 text-xs">
              বাংলাদেশে ❤️ দিয়ে তৈরি
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
