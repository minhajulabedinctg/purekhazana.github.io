import { Star, ShoppingBag } from "lucide-react";

interface Product {
  id: number;
  name: string;
  nameBn: string;
  description: string;
  price: string;
  originalPrice?: string;
  rating: number;
  emoji: string;
  badge?: string;
}

const products: Product[] = [
  {
    id: 1,
    name: "Sundarban Honey",
    nameBn: "সুন্দরবনের মধু",
    description: "সুন্দরবনের খাঁটি মধু, সরাসরি মৌচাক থেকে সংগ্রহিত",
    price: "৳৮৫০",
    originalPrice: "৳১,০০০",
    rating: 4.9,
    emoji: "🍯",
    badge: "বেস্ট সেলার",
  },
  {
    id: 2,
    name: "Pure Ghee",
    nameBn: "খাঁটি ঘি",
    description: "গাভীর দুধ থেকে তৈরি ১০০% খাঁটি দেশি ঘি",
    price: "৳৯৫০",
    rating: 4.8,
    emoji: "🧈",
  },
  {
    id: 3,
    name: "Mustard Oil",
    nameBn: "সরিষার তেল",
    description: "ঘানিতে ভাঙা খাঁটি সরিষার তেল",
    price: "৳৪৫০",
    rating: 4.7,
    emoji: "🫒",
    badge: "নতুন",
  },
  {
    id: 4,
    name: "Black Cumin",
    nameBn: "কালোজিরা",
    description: "উচ্চমানের কালোজিরা, স্বাস্থ্যের জন্য উপকারী",
    price: "৳৩৫০",
    rating: 4.9,
    emoji: "🌰",
  },
  {
    id: 5,
    name: "Dates",
    nameBn: "খেজুর",
    description: "আরবের উন্নতমানের মেডজুল খেজুর",
    price: "৳৭৫০",
    originalPrice: "৳৮৫০",
    rating: 4.8,
    emoji: "🌴",
  },
  {
    id: 6,
    name: "Coconut Oil",
    nameBn: "নারকেল তেল",
    description: "ঠাণ্ডা প্রক্রিয়ায় তৈরি ভার্জিন নারকেল তেল",
    price: "৳৫৫০",
    rating: 4.6,
    emoji: "🥥",
  },
];

const Products = () => {
  return (
    <section id="products" className="py-20 md:py-28">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary rounded-full mb-4">
            <span className="gold-dot" />
            <span className="text-sm font-medium text-secondary-foreground">
              আমাদের পণ্যসমূহ
            </span>
          </div>
          <h2 className="section-title">
            প্রকৃতির সেরা উপহার
          </h2>
          <p className="section-subtitle mx-auto">
            প্রতিটি পণ্য যত্ন সহকারে বাছাই করা এবং গুণমান পরীক্ষিত
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {products.map((product, index) => (
            <div
              key={product.id}
              className="card-fresh group relative overflow-hidden"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Badge */}
              {product.badge && (
                <div className="absolute top-4 right-4 px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full">
                  {product.badge}
                </div>
              )}

              {/* Product Emoji */}
              <div className="w-20 h-20 mx-auto mb-4 bg-secondary rounded-2xl flex items-center justify-center text-4xl transition-transform group-hover:scale-110">
                {product.emoji}
              </div>

              {/* Product Info */}
              <div className="text-center">
                <h3 className="text-lg font-bold text-foreground mb-1">
                  {product.nameBn}
                </h3>
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                  {product.description}
                </p>

                {/* Rating */}
                <div className="flex items-center justify-center gap-1 mb-4">
                  <Star className="w-4 h-4 fill-accent text-accent" />
                  <span className="text-sm font-medium text-foreground">
                    {product.rating}
                  </span>
                </div>

                {/* Price */}
                <div className="flex items-center justify-center gap-2 mb-4">
                  <span className="text-xl font-bold text-primary">
                    {product.price}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-muted-foreground line-through">
                      {product.originalPrice}
                    </span>
                  )}
                </div>

                {/* Add to Cart Button */}
                <button className="w-full btn-secondary group/btn">
                  <ShoppingBag className="w-4 h-4 mr-2" />
                  অর্ডার করুন
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* View All Link */}
        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-flex items-center gap-2 text-primary font-medium hover:underline"
          >
            সব পণ্য দেখুন
            <span className="text-lg">→</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Products;
