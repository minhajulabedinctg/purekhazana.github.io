import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "ফাতেমা খাতুন",
    location: "ঢাকা",
    content:
      "পিওর খাজানার মধু সত্যিই অসাধারণ! বাজারের অন্যান্য মধুর সাথে এর কোনো তুলনা হয় না। আমার পরিবার এখন শুধু এখান থেকেই মধু কেনে।",
    rating: 5,
    avatar: "👩",
  },
  {
    id: 2,
    name: "করিম উদ্দিন",
    location: "চট্টগ্রাম",
    content:
      "ঘি এর মান অত্যন্ত ভালো। রান্নায় ব্যবহার করলে স্বাদ একদম অন্যরকম হয়। দামও যুক্তিসঙ্গত।",
    rating: 5,
    avatar: "👨",
  },
  {
    id: 3,
    name: "সুমাইয়া আক্তার",
    location: "সিলেট",
    content:
      "ডেলিভারি খুবই দ্রুত এবং প্যাকেজিং চমৎকার। সরিষার তেলের গন্ধ ও স্বাদ একদম খাঁটি। অবশ্যই আবার অর্ডার করব।",
    rating: 5,
    avatar: "👩‍🦱",
  },
];

const Testimonials = () => {
  return (
    <section className="py-20 md:py-28">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary rounded-full mb-4">
            <span className="gold-dot" />
            <span className="text-sm font-medium text-secondary-foreground">
              গ্রাহকদের মতামত
            </span>
          </div>
          <h2 className="section-title">
            তাদের অভিজ্ঞতা শুনুন
          </h2>
          <p className="section-subtitle mx-auto">
            আমাদের সন্তুষ্ট গ্রাহকদের কিছু কথা
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.id}
              className="card-fresh relative"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <Quote className="w-5 h-5 text-primary" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                ))}
              </div>

              {/* Content */}
              <p className="text-muted-foreground mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center text-2xl">
                  {testimonial.avatar}
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.location}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
